-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2020 at 02:13 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sawjfnmg_mood704`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`username`, `password`) VALUES
('admin', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `sno` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `registration_type` varchar(50) NOT NULL,
  `no_of_tickets` varchar(50) NOT NULL,
  `number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`sno`, `name`, `email`, `mobile`, `registration_type`, `no_of_tickets`, `number`) VALUES
(75, 'chaitanya rai', 'chaitanyarai19@gmail.com', '+918435407793', 'self', '1', 1),
(81, 'Sam Smith', 'Sam60@gmail.com', '9425167368', 'self', '1', 1),
(82, 'Poel Coelho', 'Poelc34@gmail.com', '9826376548', 'group', '4', 2),
(83, 'Agatha Christie', 'Agchristie2@gmail.com', '6263548754', 'corporate', '5', 3),
(84, 'Sasha Sloan', 'Sasha76@gmail.com', '9424675643', 'other', '3', 4),
(85, 'Eric Nam', 'Nameric34@gmail.com', '6456112674', 'other', '2', 4),
(94, 'Olivia Rodrigo', 'Olivia29@gmail.com', '1234567890', 'group', '4', 2),
(96, 'Shruti Choudhary', 'shrutic29401@gmail.com', '6263235433', 'self', '1', 1),
(97, 'Olivia Rodrigo', 'Olivia29@gmail.com', '9479641625', 'group', '2', 2),
(98, 'Namjoon kim', 'Rm148@gmail.com', '6263235433', 'group', '3', 2),
(99, 'Seokjin Kim', 'Worldwide27@gmail.com', '9479641625', 'corporate', '4', 3),
(100, 'Yoongi Min', 'Sugad2@gmail.com', '6263235433', 'corporate', '5', 3),
(101, 'Tripti bhatia', 'triptibhatia@gmail.com', '6678869055', 'corporate', '1', 3),
(102, 'Hoseok Jung', 'Hobi25@gmail.com', '9479641625', 'other', '5', 4),
(103, 'Jimin Park', 'Mochi23@gmail.com', '6263235433', 'corporate', '6', 3),
(104, 'Taehyung Kim', 'Vbts23@gmail.com', '9479641625', 'self', '2', 1),
(105, 'Jungkook Jeon', 'Kookie21@gmail.com', '6263235433', 'group', '3', 2),
(106, 'Sasha Sloan', 'Sasha76@gmail.com', '9479641625', 'corporate', '3', 3),
(107, 'Sam Smith', 'Sam60@gmail.com', '9479641625', 'other', '5', 4),
(108, 'Julia Michaels', 'Julia54c@gmail.com', '6263548754', 'self', '1', 1),
(109, 'Ariana Grande', 'Grande56@gmail.com', '9479641625', 'group', '4', 2),
(110, 'Melanie Martinez', 'Melanie43@gmail.com', '6263235433', 'other', '1', 4),
(111, 'Trevor Daniel', 'Daniel67@gmail.com', '9479641625', 'group', '5', 2),
(112, 'Lewis Capaldi', 'Capaldi2020@gmail.com', '6263235433', 'self', '2', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

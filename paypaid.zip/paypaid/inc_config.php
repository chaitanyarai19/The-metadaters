<?php 

/*
$servername = "localhost";
$username = "ztrelaca_blood";
$password = "DD!CkhENwfv)";
$dbname = "ztrelaca_blood";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
*/


	$c = mysql_connect('localhost', 'sawjfnmg_mood704', 'chaitanya19');
	mysql_select_db('sawjfnmg_mood704', $c);


?>
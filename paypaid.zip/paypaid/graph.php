<?php
$connect = mysqli_connect("localhost", "sawjfnmg_mood704", "chaitanya19", "sawjfnmg_mood704");
$query = "SELECT count(*) as present_absent_count, number,
     case
         when number = 1 then 'Self'
         when number = 2 then 'Group'
		 when number = 3 then 'Corporate'
		 when number = 4 then 'other'
       end as number FROM user_details GROUP BY number ;";
$result = mysqli_query($connect, $query);
$i=1;
while ($row = mysqli_fetch_array($result)) {
    $label[$i] = $row["number"];
    $count[$i] = $row["present_absent_count"];
    $i++;
}
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Event Registration</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="file/css/nav.css">

<style>
body {
    width: 860px;
    margin: 0 auto;
}
div.dashed {border-style: dashed;}
</style>


</head>
<body>
    <!-- Three dot menu Starts -->
    <div class="header">
        <div class="dropdown">
            <ul class="dropbtn icons btn-right showLeft" onclick="showDropdown()">
                <li></li>
                <li></li>
                <li></li>
            </ul>
            <div id="myDropdown" class="dropdown-content">
            <a href="index.php">Home</a>
            <a href="search.php">Search</a>
            </div>
        </div>
    </div>   
    <!-- Three dot menu Ends -->
    <!-- Body part-->
    <center><h1><b><u>Number Of Event Registration</u></b></h1>
        <div style="background:#353839;width:440px;height:360px; box-shadow: 0px 0px 10px #666666;border-radius: 20px; align-items: center; margin-top: 10%;">
            <div id="piechart" class="dashed" style="width:400px;height:350px; align:center;">
            </div>
        </div>
    </center>
    <!--Body part ends-->
    
    <!-- script function for pie chart starts-->            
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">  
google.charts.load('current', {'packages':['corechart']});  
google.charts.setOnLoadCallback(drawPieChart);  

function drawPieChart()  
{  
    var pie = google.visualization.arrayToDataTable([  
              ['numberde', 'Numbder'],
              ['<?php echo $label[1]; ?>', <?php echo $count[1]; ?>],
              ['<?php echo $label[2]; ?>', <?php echo $count[2]; ?>],
              ['<?php echo $label[3]; ?>', <?php echo $count[3]; ?>],
              ['<?php echo $label[4]; ?>', <?php echo $count[4]; ?>],			  
         ]);  
    var header = {  
          //title: 'Percentage of Registration Type',
          slices: {0:{color: '#FFC0CB'}, 1:{color: '#006EFF'}, 2:{color: '#FF0000'} ,3:{color: '#9ACD32'}}
         };  
    var piechart = new google.visualization.PieChart(document.getElementById('piechart'));  
    piechart.draw(pie, header);  
} 

google.charts.load('current', {packages: ['corechart', 'bar']});
google.charts.setOnLoadCallback(drawColumnChart);

</script>
<!-- script function for pie chart ends-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="file/js/dot.js"></script>
    
</body>
</html>
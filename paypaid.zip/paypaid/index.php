<!-- This is a php code to send the details in the database--> 
<?php

	if(isset($_GET['send'])) {
       	include('inc_config.php');
			$a = $_GET['name'];
			$b = $_GET['email'];
			$c = $_GET['phone'];
			$d = $_GET['regis_type'];
			$e = $_GET['ticket'];
			//$f = $_GET['number'];		
			$d=$_GET['regis_type'];
if($d=='self'){
    $f=1;
}else if($d=='group'){
    $f=2;
}else if($d=='corporate'){
    $f=3;
}else{
    $f=4;
}
			
			$g = "INSERT INTO user_details (name, email, mobile, registration_type, no_of_tickets, number) VALUES ('$a', '$b', '$c', '$d', '$e', '$f')";
			$h = mysql_query($g) or die(mysql_error());

			echo "<script>alert('Please Preview Your Details !!!');</script>";
			echo "<script>window.location.href='update.php';</script>";
	}
?>
<!-- End of php-->

<!doctype html>
<html lang="en">

    <head>
    <title>Event Registration</title>
    
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	 <!--Css link to give the color and design to the form-->
	   <link rel="stylesheet" type="text/css" href="file/main.css">	
        <link rel="stylesheet" type="text/css" href="file/css/master.css">
         <link rel="stylesheet" href="file/bootstrap.min.css">
          <link rel="stylesheet" href="file/css/size.css">
          
            <!-- End of css-->

    </head>
    <body style="font-family: Arial; background:#DBF3FA; center fixed ;">
	
	<div class="header">
    <!-- Three dot menu Starts -->
    <div class="dropdown">
        <ul class="dropbtn icons btn-right showLeft" onclick="showDropdown()">
            <li></li>
            <li></li>
            <li></li>
        </ul>
    <div id="myDropdown" class="dropdown-content">
        <a href="admin.php">Admin Login</a>
    </div>
     </div>
      </div>
	<!--Three dot menu ends -->
	
	<!--Here contact Form starts-->
        <div class="map_1" id="main_body" align="center" style="background:#;">
		 <div class="container-contact100">
		  <div class="wrap-contact100">
		    
			<form class="contact100-form validate-form"  action="#" method="GET" >
				<span class="contact100-form-title">
					Registration Form 
				</span>
	
	
				<label class="label-input100" for="first-name">Your Name </label>
				<div class="wrap-input100 ">
				<input id="first-name" class="input100" type="text" name="name" placeholder="Enter Your Name" required>
				<span class="focus-input100"></span>
				</div>
				
				<label class="label-input100" for="phone">Phone Number</label>
				<div class="wrap-input100">
				<input id="phone" class="input100" type="text" name="phone" placeholder="Eg. +1 800 000000" required>
				<span class="focus-input100"></span>
				</div>
				

				<label class="label-input100" for="email">Email Address </label>
				<div class="wrap-input100 ">
					<input id="email" class="input100" type="text" name="email" placeholder="Eg. example@email.com" required>
					<span class="focus-input100"></span>
				</div>

				
				<label class="label-input100" for="roll">Number of Tickets</label>
				<div class="wrap-input100">
				<input id="phone" class="input100" type="text" name="ticket" placeholder="Eg. 1/2/3/4" required>
				<span class="focus-input100"></span>
				</div>
				
				<!--<label class="label-input100" for="roll">Select Your Image</label>
				<div class="wrap-input100">
				<input  id="phone" class="input100" type="file" name="f1" placeholder="hello">
				<span class="focus-input100"></span>
				</div>-->

				<label class="label-input100" for="roll">Registration Type</label>
			    <div class="drop_down"  required>
			    <select name="regis_type" class="c-form-profession form-control" style="height:50px;" id="c-form-profession" required>
					 <option value="Select Your Branch">Select Your category</option>
					 <option value="self">Self</option>
					 <option value="group">Group</option>
				     <option value="corporate">Corporate</option>
					 <option value="other">Other</option>
				</select>
				</div>

<br><br><br><br><br>
				<div class="container-contact100-form-btn">
					<button class="contact100-form-btn" name="send">
						<span type="submit" >
							Submit
						</span>
					</button>
					
				</div>
			</form>
		</div>
	</div>
</div>


				

<!-- here form is end-->
    <script src="file/js/dot.js"></script>	




</body>
</html>
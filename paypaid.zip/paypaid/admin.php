<!--code to check the userID and Password From database-->
<?php
 
if(isset($_GET['send'])) {
 
ob_start();

$cn = mysql_connect("localhost", "sawjfnmg_mood704", "chaitanya19");
mysql_select_db("sawjfnmg_mood704", $cn);
 
 $a = $_GET['username'];
 $b = $_GET['password'];
 
 $c = "SELECT * FROM admin_login WHERE username='$a' AND password='$b'";
 $d = mysql_query($c) or die(mysql_error());
 $e = mysql_num_rows($d);
 
 if($e==1) {
   // $_SESSION['send']=$a;  
	echo "<script>window.location.href='search.php';</script>";
 } else {
	echo "INVALID USERNAME AND PASSWORD COMBINATION";
 }
 ob_end_flush();
 }
?>
<!--code to check the userID and Password From database-->


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Admin Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" type="text/css" href="login/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="login/css/util.css">
	<link rel="stylesheet" type="text/css" href="login/css/main.css">
</head>
<body>
	<!--login form starts-->
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-form-title" style="background-image: url(images/bg-01.jpg);">
					<span class="login100-form-title-1">
						Admin &nbsp;&nbsp;Login 
					</span>
				</div>

				<form class="login100-form validate-form" method="GET"/>
					<div class="wrap-input100 validate-input m-b-26">
						<span class="label-input100">Username</span>
						<input class="input100" type="text" name="username" placeholder="Enter username" required>
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-18">
						<span class="label-input100">Password</span>
						<input class="input100" type="password" name="password" placeholder="Enter password" required>
						<span class="focus-input100"></span>
					</div>
                     
					  <br>
					  <br>
					   
					<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="send">
							Login
						</button>
					</div>
				</form>
				
			</div>
		</div>
	</div>
	<!--login form Ends-->
	
	
    <script src="login/js/main.js"></script>

</body>
</html>
<?php
session_start(); 

include('inc_config.php');
?>


<?php

	if(isset($_GET['send'])) {
       	include('inc_config.php');
			$a = $_GET['name'];
			$b = $_GET['phone'];
			$c = $_GET['email'];
			$d = $_GET['regis_type'];
			$e = $_GET['ticket'];
					
			
			$f = "update user_details set name='$a',mobile='$b',email='$c', registration_type='$d',no_of_tickets ='$e' order by sno desc limit 1";
			$g = mysql_query($f) or die(mysql_error());

			//echo "<script>alert('You are successfully registered !!!');</script>";
			echo "<script>window.location.href='registration.php';</script>";		
			
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <title>Event Registration</title>
	<meta charset="UTF-8">
	 <meta name="viewport" content="width=device-width, initial-scale=1">
	   <link rel="stylesheet" type="text/css" href="file/main.css">	
        <link rel="stylesheet" type="text/css" href="file/css/master.css">
          <link rel="stylesheet" href="file/bootstrap.min.css">
            <link rel="stylesheet" href="file/css/size.css">
          
          
</head>
<body style="font-family: Arial; background:#DBF3FA; center fixed ;">


<?php
		
		//$sno = $_GET['sno'];		
		//$a = "SELECT * FROM blood WHERE mobile=$sno";
		include('inc_config.php');
		$a = "SELECT * FROM user_details order by sno desc limit 1 ";
		$b = mysql_query($a) or die(mysql_error());
		
		while($row=mysql_fetch_array($b)) {
			extract($row);
?>
		
  <div class="map_1" id="main_body" align="center" style="background:#;">
	<div class="container-contact100">
		<div class="wrap-contact100">
		
			<form class="contact100-form validate-form" method="GET" >
				<span class="contact100-form-title">
					Preview Form
				</span>

				<label class="label-input100" for="first-name">Your FULL Name *</label>
				<div class="wrap-input100 validate-input">
					<input id="email" class="input100" type="text" value="<?php echo $name; ?>" name="name" placeholder="Eg. Robert Downey " required>
					<span class="focus-input100"></span>
				</div>
				
				<label class="label-input100" for="phone">MOBILE Number *</label>
				<div class="wrap-input100">
					<input id="phone" class="input100" type="text" value="<?php echo $mobile; ?>" name="phone" placeholder="Eg. +1 800 000000" required>
					<span class="focus-input100"></span>
				</div>

				<label class="label-input100" for="email">Email Address *</label>
				<div class="wrap-input100 validate-input">
					<input id="email" class="input100" type="text" value="<?php echo $email; ?>" name="email" placeholder="Eg. example@email.com" required>
					<span class="focus-input100"></span>
				</div>

				

				<label class="label-input100" for="roll">REGISTRATION TYPE *</label>
		<div class="wrap-input100 validate-input">
					<input id="" class="input100" type="text" value="<?php echo $registration_type; ?>" name="regis_type" placeholder="Eg. Self/other" required>
					<span class="focus-input100"></span>
				</div>
				
							
				<label class="label-input100" for="phone">Number OF TICKETS</label>
				<div class="wrap-input100">
					<input id="phone" class="input100" type="number" value="<?php echo $no_of_tickets; ?>" name="ticket" placeholder="Eg. 1" required>
					<span class="focus-input100"></span>
				</div>				
				
			
				<div class="container-contact100-form-btn">
					<button class="contact100-form-btn" name="send">
						<span>
							Submit
						</span>
					</button>
				</div>
				
			</form>
			<?php
			}
		?>

		
	</div>
	 </div>
	  </div>
</body>
</html>
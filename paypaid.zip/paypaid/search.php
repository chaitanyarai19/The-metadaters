<?php
include('inc_config.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Event Registration</title>
    <!-- From here css links Starts--> 
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="file/main.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="file/css/nav.css">
    <!-- From here css links Ends-->
               

</head>
<body>
    
	<div class="header">
    <!-- Three dot menu Starts -->
    <div class="dropdown">
        <ul class="dropbtn icons btn-right showLeft" onclick="showDropdown()">
            <li></li>
            <li></li>
            <li></li>
        </ul>
    <div id="myDropdown" class="dropdown-content">
        <a href="index.php">Home</a>
        <a href="graph.php">Graph</a>
    </div>
     </div>
      </div>   
    

<div class="container">	
<div class="container-fluid">
    <!--heading Start-->
	<center>
	<h1>
	  <u>
	   <b>Search Registration</b>
	  </u>
	</h1>
	</center>
	<!--heading End-->
    <br><br>
<!--Serach Form Starts-->
<form method="POST">
    
    <center>
	<div class="row" style="background:#eee; width:500px; height:200px; padding:15px 0 15px 0;">
	    
        <div class="drop_down"  required>
	        <div class="wrap-input100 validate-input">
		        <select name="registration_type" class="c-form-profession form-control" style="height:55px;width:400px;"   required>
		        	<option value="No">Select Registration Type </option>
			        <option value="Self">Self</option>
			        <option value="Group">Group</option>
			        <option value="Corporate">Corporate</option>
			        <option value="Other">Other</option>
		        </select>
		    </div>
	    </div>
	
	    <div class="container-contact100-form-btn">
		    <button class="contact100-form-btn" name="search">
			    <span name="search">
				Submit
			    </span>
		    </button>
	    </div>
		
    </div>
    </center>
</form>
<!--Serach Form Ends-->	
</div>
<br><br>

<!-- Table Content Starts-->
<?php 
	if(isset($_POST['search'])){
	$a = $_POST['registration_type'];
?>

        <center>
            <h2 style="text-transform:uppercase;">List of <span style="color:#ec9787; font-weight:bold; font-size:51px;"><?php echo $a; ?></span> Registration</h2>
        </center>
        <br><br>
        
        <div class="table-responsive">
            <table class="table table-compressed table-hover" style="font-size:18px;">
                <tr>
	                <th>S No.</th>
	                <th>Name</th>
	                <th>Mobile</th>
	                <th>Email</th>
	                <th>Registration Type</th>
                	<th>Number of Tickets</th>
                </tr>


<?php 		
		$b = "SELECT * FROM user_details WHERE registration_type='$a'";
		$c = mysql_query($b) or die(mysql_error());
		$count=1;
		while($row=mysql_fetch_array($c)) {
			extract($row);
?>

                <tr>
                	<td><?php echo $count; $count++; ?></td>
	                    <td style="text-transform:uppercase;"><?php echo $name; ?></td>
	                    <td><?php echo "<a href='tel:$mobile'>$mobile</a>"; ?></td>
	                    <td><?php echo "<a href='mailto:$email'>$email</a>"; ?></td>
	                    <td><?php echo $registration_type; ?></td>
	                    <td><?php echo $no_of_tickets; ?></td>
                </tr>
<?php
		}
	}
?>

            </table>
        </div>
<?php
	if(!isset($_POST['search'])) {	
?>
	<?php } ?>
	
</div>
<!-- Table Content Ends-->


 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
 <script src="file/js/dot.js"></script>
	  </body>
	  </html>
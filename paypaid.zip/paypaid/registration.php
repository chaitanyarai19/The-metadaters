<!DOCTYPE html>
<html>
<head>
	<title>Event Registration</title>
	       <style>
	     @media screen and (max-width: 2000px) {
            .map_1 {
          max-width:600px;
          
          }
   }
 @media screen and (max-width: 1200px) {
            .map_1 {
          max-width:600px;
          
          }
 
   }

       @media screen and (max-width: 630px) {
  .map_1 {
    max-width:500px;
  }

}
	</style>
	
</head>
<body>
    
<center>
	<div class="map_1"  style="box-shadow: 0px 0px 10px #666666;border-radius: 20px; align-items: center; margin-top: 10%; height:300px;">
		
				<center><img src="images/download.png"></center>
					<h1><b>Your Registration Is Successfully Completed</b></h1>
<!-- php code for generation Random ID-->
<?php
$code_feed = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
$code_length = 10;  // Set this to be your desired code length
$final_code = "";
$feed_length = strlen($code_feed);

for($i = 0; $i < $code_length; $i ++) {
	$feed_selector = rand(0,$feed_length-1);
	$final_code .= substr($code_feed,$feed_selector,1);
}
?>
<!-- php code for generation Random ID-->

        <h2>Your Registration ID :- <span style="color:green;"><?php echo $final_code; ?></span></h2>

    </div>
</center>

<?php
     //include('inc_config.php');
		//$a = $final_code;
		//$b = "INSERT INTO user_details (registration_id) VALUES ('$a')";
		//$c = mysql_query($b) or die(mysql_error());

?>


<script>
  history.pushState(null, null, document.title);
window.addEventListener('popstate', function () {
    history.pushState(null, null, document.title);
});
</script>
</body>
</html>